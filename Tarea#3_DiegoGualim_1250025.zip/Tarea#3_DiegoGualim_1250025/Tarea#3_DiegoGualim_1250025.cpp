#include <iostream>
#include <stdlib.h>
using namespace std;

void esMultiploDeTres(int,int);
int restarTres(int);

void esMultiploDeTres(int numOriginal, int numero)
{
	if (numero == 0)
	{
		cout << "El numero " << numOriginal << " es multiplo de 3";
	}
	else
	{
		cout << "El numero " << numOriginal << " no es multiplo de 3";
	}
}

int restarTres(int numero)
{
	int numOriginal = numero;
	
	if (numero <= 0)
	{
		return numero;
	}
	else
	{
		return restarTres(numero - 3);
	}
}

int main()
{
	int numero;

	cout << "Ingresa un numero entero: ";
	cin >> numero;

	int numOriginal = numero;

	numero = restarTres(numero);
	esMultiploDeTres(numOriginal,numero);

}